# workout_tracker
track and design your workout plan using the scientific method. 

How to run?
1.run the main.py
