from ui import WorkoutTrackerUI

if __name__ == "__main__":
    app = WorkoutTrackerUI()
    app.run()
